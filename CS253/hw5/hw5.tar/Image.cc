#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <vector>
#include <sstream>
#include "Image.h"
#include "Alpha.h"
#include "PGM.h"


using namespace std;

Image* Image::create(string filename) {
    string cat1 = filename.substr(filename.length()-5, filename.length());
    string cat2 = filename.substr(filename.length()-3, filename.length());
    // cout << cat1 << ", " << cat2 << '\n';
    if(cat1 == "alpha") {
        Image *pointer = new Alpha(filename);
        return pointer;
    }
    if(cat2 == "pgm") {
        Image *pointer = new PGM(filename);
        // cout << "created pointer\n";
        return pointer;
    }
    else {
        throw "could not create image using file: " + filename;
    }
    return NULL;
}

Image::~Image() {

}

bool Image::empty() {
    return array.empty();
}

int Image::height(){
    return 1;
}

int Image::width(){
    return 1;
}

void Image::mirror() {
    vector<vector<int>> mirror;
    int oldi = 0;
    int oldj = 0;

    mirror.resize(countX, vector<int>( countY , 0));

    for(int i = 0; i < countY; i++) {
        for(int j = 0; j < countX; j++) {
          oldi = i;
          oldj = countX - 1 - j;
          mirror[j][i] = array[oldj][oldi];
        }
    }
    array = mirror;
}

void Image::rotate(int degrees) {
    vector<vector<int>> newArray;
    newArray.resize(countY, vector<int>( countX , 0));

    if(degrees % 90 != 0) {
        throw string("invaild rotation: %d\n", degrees);
    }

    for(int i = 0; i < countX; i++ ) {
        for(int j = 0; j < countY; j++ ) {
            newArray[newArray.size()-j-1][i] = array[i][j];
        }
    }
    int temp = countY;
    countY = countX;
    countX = temp;
    array = newArray;
    if(degrees / 90 != 1) {
        rotate(degrees-90);
    }
}
