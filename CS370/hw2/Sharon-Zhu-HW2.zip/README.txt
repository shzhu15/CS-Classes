README
======

This package includes the following files.

|-- Coordinator.c [This is the main program]
|-- Checker.c [program to test divisible]
|-- README.txt [This file]
|-- Makefile [file to help compile, clean and package]


To compile:
    make

To run:
    ./Coordinator <number to test divisible> <number> <number> <number> <number>

To clean:
    make clean
