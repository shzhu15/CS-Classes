README
======

This package includes the following files.

|-- SkeletonSchedular.c [This is the driver program which will be used to implement the CPU Schedular.]
|-- Makefile [Makefile is implemented here.]
|-- README.txt [This file]

To compile:
    gcc SkeletonSchedular.c

    or

    make

To make clean:
    make clean

To run:
    hw5.out <file>

For example;
    hw5.out FirstInput
